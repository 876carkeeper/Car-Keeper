# Put CarKeeper online using only an iPhone

You will not need a computer, a terminal, or any command line.
Plan: **GitHub** holds the files, **Render** runs them for free, then you add the site to your
Home Screen. About 15 minutes, mostly waiting for the first build.

Everything is already configured: prices, products, the billing portal, and webhook
registration. You only supply your Stripe test key.

---

## Part 1 — Get the files into GitHub (5 min)

1. In this chat, tap the file card **`carkeeper-iphone.zip`** and save it to your phone.
2. Open the **Files** app → **Downloads** → tap the zip once. iOS unzips it into a folder
   called **carkeeper**. Open that folder: you should see
   `index.html`, `server.js`, `package.json`, `ENV-VALUES.txt`, several `.png` icons,
   `sw.js`, `manifest.webmanifest`, `DEPLOY-IPHONE.md`.
   (Do not worry about order; nothing lives in a sub-folder.)
3. In Safari go to **github.com** and sign in (or create a free account).
4. Tap **+** (top right) → **New repository**.
   - Repository name: `carkeeper`
   - Choose **Private**
   - Tap **Create repository**
5. On the new empty repo page tap **uploading an existing file** (or **Add file → Upload files**).
6. Tap **choose your files** → **Browse** → navigate to the extracted **carkeeper** folder →
   tap **Select** (top right) → select **all** the files → **Open**.
7. Wait for all files to appear in the list, then tap **Commit changes** (green button).

> If Safari refuses to select many files at once, upload them in two batches — but keep every
> file in the repository root, not in a sub-folder.

---

## Part 2 — Deploy on Render (8 min)

1. Go to **render.com** → **Get Started** → **GitHub** → authorise it.
2. Tap **New +** → **Web Service**.
3. Choose your **`carkeeper`** repository → **Connect**.
4. Fill the form:
   - **Name:** `carkeeper` (this becomes your address; if it is taken, add something like `carkeeper-alex`)
   - **Region:** any, closest to you
   - **Branch:** `main`
   - **Runtime:** Node
   - **Build Command:** `npm install`
   - **Start Command:** `npm start`
   - **Instance Type:** **Free**
5. Open **Advanced** (or the **Environment** tab) and add the nine variables from
   **`ENV-VALUES.txt`** — one row per line, Name and Value.
   **This is the only fiddly part.** The five `price_…` / `bpc_…` values can be copied
   straight from that file; `STRIPE_SECRET_KEY` you copy from Stripe (instructions are at the
   bottom of `ENV-VALUES.txt`).
6. Tap **Create Web Service** and wait 2–4 minutes. The log ends with
   `CarKeeper running on …`. Render shows your address at the top of the page — it looks like
   `https://carkeeper-xxxx.onrender.com`.
7. Check that `APP_URL` matches that address exactly, with no trailing slash. Save if you
   changed it (Render redeploys automatically).

**That's it — the app is live.** Open the address in Safari.

---

## Part 3 — Install it like a real app (30 seconds)

In Safari, with your CarKeeper address open:

1. Tap the **Share** button (square with an arrow).
2. Scroll down → **Add to Home Screen** → **Add**.

You now have a CarKeeper icon that opens full-screen with no browser bars, and it keeps
working when the phone is offline (your vehicles and records live on the device).

---

## Part 4 — Prove payments work (2 min)

1. In the app: **Settings → Subscription**.
2. You should see a **“Stripe test mode”** notice. That means the server is talking to Stripe.
3. Tap **Subscribe** on Basic ($4.99/month).
4. On Stripe's page use card **4242 4242 4242 4242**, any future expiry, any CVC, any ZIP.
   If a phone number is requested, toggle off “Save my information” instead of typing one.
5. You land back in CarKeeper, and within a few seconds Settings shows
   **CarKeeper Basic · active · Renews <date>**.
6. In Stripe → **Payments**, your $4.99 test charge is listed. No real money moved.

Then tap **Manage billing & cancellation** → that opens Stripe's billing portal, where you can
change the card, switch to Premium, or cancel at period end. All of that is live.

---

## What happens automatically (you do not need to touch these)

- **Webhook registration.** On first start the server creates its own Stripe webhook endpoint
  for `APP_URL/api/stripe/webhook` and stores the signing secret. Renewals, portal changes and
  failed payments then update the app on their own.
- **Redirect URLs.** Return-from-checkout URLs follow whatever domain the app is served from,
  so nothing breaks if Render renames your address.
- **Billing portal.** Already configured through the API — no dashboard setup needed.

To confirm the webhook registered, open `https://your-address/api/health` in Safari:
`"webhookSecret": true` means it succeeded.

---

## Things to know about the free tier

- **First load after a quiet spell takes ~30 seconds.** Free Render services sleep after
  ~15 minutes of no traffic. They wake on the next visit. Upgrading removes this.
- **There is no permanent disk on the free tier.** If Render restarts or you redeploy, the
  server forgets its local table of who is subscribed — but **nobody loses their paid plan**,
  because the app re-reads the real subscription from Stripe every time it loads. Your
  vehicles, records and expenses are stored on your phone, not on the server, so they are
  never affected.
- **Test mode only.** Nothing charges real cards until you replace `sk_test_…` with `sk_live_…`.

---

## If something looks wrong

| What you see | What it means |
|---|---|
| Build fails, log mentions `node:sqlite` | The service is on an old Node. Set `NODE_ENV=production` and add a variable `NODE_VERSION` = `24.11.0`, then redeploy |
| Plan screen says **“Payments server not connected”** | You opened a cached copy, or the server crashed. Open the Render log and look for the last red line |
| Tap Subscribe → “Stripe rejected the API key” | `STRIPE_SECRET_KEY` has a typo, a space, or is a live key while prices are test prices |
| Lands on Free after paying | The server was asleep. Wait a few seconds and reopen — it re-syncs from Stripe automatically |
| `/api/health` shows `"webhookSecret": false` | `APP_URL` does not match the real address. Fix it in Environment and redeploy |
| “Manage billing” errors | `STRIPE_PORTAL_CONFIG_ID` is missing from the Environment variables |

---

## When you are ready for real payments

1. In Stripe, finish account activation (business details, bank account).
2. Replace `STRIPE_SECRET_KEY` with your live `sk_live_…` key, and set `APP_URL` if the domain
   changes.
3. Redeploy. The server registers a **live** webhook on its own.
4. Do one small real purchase, confirm it appears in Stripe → Payments, then refund it.

Before that, one thing should change: the server currently trusts the email the browser sends,
so anyone who knows a subscriber's email could claim their plan. That is fine in test mode and
is the last item on the list for taking real money.
